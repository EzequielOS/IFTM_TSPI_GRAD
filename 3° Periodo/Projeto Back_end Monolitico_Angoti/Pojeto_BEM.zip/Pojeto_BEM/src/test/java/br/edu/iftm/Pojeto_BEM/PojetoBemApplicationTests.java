package br.edu.iftm.Pojeto_BEM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PojetoBemApplicationTests {

	@Test
	void contextLoads() {
	}

}
