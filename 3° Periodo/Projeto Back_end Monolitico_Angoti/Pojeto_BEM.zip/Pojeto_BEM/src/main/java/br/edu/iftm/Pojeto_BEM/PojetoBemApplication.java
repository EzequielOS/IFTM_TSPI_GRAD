package br.edu.iftm.Pojeto_BEM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PojetoBemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PojetoBemApplication.class, args);
	}

}
