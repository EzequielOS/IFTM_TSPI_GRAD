package br.edu.iftm.Projeto_BEM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoBemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoBemApplication.class, args);
	}

}
