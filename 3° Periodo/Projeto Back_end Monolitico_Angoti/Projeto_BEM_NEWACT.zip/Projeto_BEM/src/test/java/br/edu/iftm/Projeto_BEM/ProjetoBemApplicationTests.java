package br.edu.iftm.Projeto_BEM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBemApplicationTests {

	@Test
	void contextLoads() {
	}

}
