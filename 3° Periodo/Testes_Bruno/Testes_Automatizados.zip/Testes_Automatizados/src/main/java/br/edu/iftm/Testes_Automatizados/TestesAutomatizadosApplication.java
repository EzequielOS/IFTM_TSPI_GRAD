package br.edu.iftm.Testes_Automatizados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestesAutomatizadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestesAutomatizadosApplication.class, args);
	}

}
