package br.edu.iftm.Testes_Automatizados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestesAutomatizadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
