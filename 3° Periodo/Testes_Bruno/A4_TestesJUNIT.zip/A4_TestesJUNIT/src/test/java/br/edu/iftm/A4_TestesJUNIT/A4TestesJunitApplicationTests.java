package br.edu.iftm.A4_TestesJUNIT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A4TestesJunitApplicationTests {

	@Test
	void contextLoads() {
	}

}
