package br.edu.iftm.A4_TestesJUNIT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A4TestesJunitApplication {

	public static void main(String[] args) {
		SpringApplication.run(A4TestesJunitApplication.class, args);
	}

}
